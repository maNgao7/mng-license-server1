import puppeteer from "puppeteer";

const edgePath = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe";
console.log("Launching Edge from:", edgePath);
const b = await puppeteer.launch({
    executablePath: edgePath,
    headless: true,
    args: ["--no-sandbox", "--disable-blink-features=AutomationControlled"]
});
const p = await b.newPage();
await p.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
console.log("Navigating to TikTok profile...");
await p.goto("https://www.tiktok.com/@tiktok", { waitUntil: "domcontentloaded", timeout: 20000 });
const content = await p.content();
console.log("Page content length:", content.length);
const match = content.match(/"avatarLarger":"([^"]+)"/);
if (match) {
    console.log("Found avatarLarger:", match[1].substring(0, 80));
} else {
    console.log("avatarLarger not found in HTML");
}
await b.close();
