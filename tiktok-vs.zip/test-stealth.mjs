import puppeteer from "puppeteer";

const edgePath = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe";

(async () => {
    try {
        const b = await puppeteer.launch({
            executablePath: edgePath,
            headless: "new",
            args: [
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-blink-features=AutomationControlled",
                "--window-size=1280,800",
                "--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"
            ]
        });
        const p = await b.newPage();
        await p.setExtraHTTPHeaders({
            "Accept-Language": "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7",
            "Sec-Ch-Ua": '"Chromium";v="124", "Microsoft Edge";v="124", "Not-A.Brand";v="99"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": '"Windows"'
        });
        await p.evaluateOnNewDocument(() => {
            Object.defineProperty(navigator, 'webdriver', { get: () => false });
        });
        console.log("Navigating...");
        await p.goto("https://www.tiktok.com/@tiktok", { waitUntil: "networkidle2", timeout: 25000 });
        const html = await p.content();
        console.log("HTML length:", html.length);
        const match = html.match(/"avatarLarger":"([^"]+)"/);
        console.log("Match avatarLarger:", match ? "FOUND: " + match[1].slice(0, 50) : "NO MATCH");
        await b.close();
    } catch (e) {
        console.error("Error:", e.message);
    }
})();
