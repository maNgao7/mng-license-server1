import http from "http";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { TikTokLiveConnection, WebcastEvent } from "tiktok-live-connector";
import puppeteer from "puppeteer";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 8088;
const BRIDGE_VERSION = "6.5.0";
const FALLBACK_EULER = "euler_NTYyZDA5YjBlNTNjMDA3YzI1YmVlYmI2YzNmN2Y0ZDczMzgyYzUwMWJlODUzYzM5YTk2NTBi";

let eulerApiKey = "";
const possibleKeyFiles = [
    path.join(__dirname, "euler-api-key.txt"),
    "C:\\Users\\User\\Desktop\\MNG-TikTok-Game\\apps\\tiktok-vs\\euler-api-key.txt",
    "C:\\Users\\User\\Desktop\\MNG-TikTok-Game\\apps\\mng-orbit\\euler-api-key.txt",
    "C:\\Users\\User\\.gemini\\antigravity\\scratch\\UnturnedModStudio\\euler-api-key.txt"
];

for (const kf of possibleKeyFiles) {
    try {
        if (fs.existsSync(kf)) {
            const val = fs.readFileSync(kf, "utf-8").trim();
            if (val) {
                eulerApiKey = val;
                console.log(`[TikTok Bridge] Euler API Key yüklendi (${kf})`);
                break;
            }
        }
    } catch (e) {}
}

if (!eulerApiKey) {
    eulerApiKey = FALLBACK_EULER;
    console.log("[TikTok Bridge] Varsayılan Euler API Key kullanılıyor.");
}

let connection = null;
let currentUsername = "";
let connectionStatus = "disconnected"; // disconnected, connecting, connected, offline, error
let lastError = "";
let eventQueue = [];
const giftStreakCounts = new Map();
const recentFollowEvents = new Map();
let reconnectTimer = null;
let avatarBrowser = null;
let avatarBrowserPromise = null;

const avatarMemoryCache = new Map();
const avatarCacheDirs = [
    path.join(__dirname, ".avatar-cache"),
    "C:\\Users\\User\\Desktop\\MNG-TikTok-Game\\apps\\tiktok-vs\\.avatar-cache"
].filter((value, index, array) => array.indexOf(value) === index);

function widgetGiftPost(payload) {
    try {
        const body = JSON.stringify(payload);
        const req = http.request({ hostname: "127.0.0.1", port: 31975, path: "/api/widget/gift", method: "POST", headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) }, timeout: 800 }, () => {});
        req.on("error", () => {}); req.end(body);
    } catch {}
}

function widgetLikePost(payload) {
    try {
        const body = JSON.stringify(payload);
        const req = http.request({ hostname: "127.0.0.1", port: 31975, path: "/api/widget/like", method: "POST", headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) }, timeout: 800 }, () => {});
        req.on("error", () => {}); req.end(body);
    } catch {}
}

function queueEvent(event) {
    const rawType = String(event.eventType || event.type || "").trim();
    const countVal = Number(event.repeatCount ?? event.likeCount ?? event.count ?? 1);
    const normalized = {
        eventType: rawType,
        type: rawType,
        username: String(event.username || event.uniqueId || event.displayId || "Izleyici"),
        uniqueId: String(event.username || event.uniqueId || event.displayId || "Izleyici"),
        displayId: String(event.username || event.uniqueId || event.displayId || "Izleyici"),
        nickname: String(event.nickname || event.username || "Izleyici"),
        avatarUrl: String(event.avatarUrl || event.avatar || event.profilePictureUrl || ""),
        avatar: String(event.avatarUrl || event.avatar || event.profilePictureUrl || ""),
        profilePictureUrl: String(event.avatarUrl || event.avatar || event.profilePictureUrl || ""),
        giftId: String(event.giftId ?? ""),
        giftName: String(event.giftName || event.name || ""),
        name: String(event.giftName || event.name || ""),
        repeatCount: Math.max(1, countVal),
        likeCount: Math.max(1, countVal),
        count: Math.max(1, countVal),
        diamondCount: Number(event.diamondCount ?? 0),
        timestamp: event.timestamp || Date.now()
    };

    eventQueue.push(normalized);

    // Unity'nin yerel HTTP istekleri engellenebildiğinde veya geciktiğinde,
    // her olayı diske JSON olarak yazarak ikinci bir güvenilir aktarım kanalı sağlıyoruz.
    const candidateDirs = [
        String(process.env.MNG_UNTURNED_MOD_DIR || "").trim(),
        "D:\\SteamLibrary\\steamapps\\common\\Unturned\\Modules\\UnturnedModEdition",
        "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Unturned\\Modules\\UnturnedModEdition"
    ].filter(d => d && fs.existsSync(d));

    const uniqueDirs = Array.from(new Set(candidateDirs));
    for (const dir of uniqueDirs) {
        try {
            const queueDir = path.join(dir, "live-event-queue");
            if (!fs.existsSync(queueDir)) fs.mkdirSync(queueDir, { recursive: true });
            const stamp = `${Date.now()}-${process.pid}-${Math.random().toString(16).slice(2)}`;
            const tempFile = path.join(queueDir, `${stamp}.tmp`);
            const eventFile = path.join(queueDir, `${stamp}.json`);
            fs.writeFileSync(tempFile, JSON.stringify(normalized), "utf8");
            fs.renameSync(tempFile, eventFile);
        } catch (error) {
            console.error("[TikTok Bridge] File queue write failed:", error.message);
        }
    }

    if (eventQueue.length > 2000) eventQueue.splice(0, eventQueue.length - 2000);
}

function shouldQueueFollow(username) {
    const key = String(username || "").toLocaleLowerCase("tr-TR");
    const now = Date.now();
    const previous = recentFollowEvents.get(key) || 0;
    recentFollowEvents.set(key, now);
    if (recentFollowEvents.size > 1000) {
        for (const [name, timestamp] of recentFollowEvents) {
            if (now - timestamp > 60000) recentFollowEvents.delete(name);
        }
    }
    return !previous || now - previous > 15000;
}

for (const dir of avatarCacheDirs) {
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) {}
}

function clearReconnect() {
    if (reconnectTimer) {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
    }
}

function extractUserAvatar(data) {
    if (!data) return "";
    const user = data.user || data.userDetails || data;
    const details = data.userDetails || {};
    const userInfo = data.userInfo || {};
    const candidates = [
        user.avatarLarger, user.avatarLarge, user.avatar_larger, user.avatar_large,
        user.avatarMedium, user.avatar_medium, user.avatarThumb, user.avatar_thumb,
        user.profilePictureUrl, user.profile_picture_url, user.avatarUrl, user.avatar_url,
        user.avatar, user.picture, user.pictureUrl,
        details.avatarLarger, details.avatarLarge, details.profilePictureUrl, details.profilePictureUrls,
        userInfo.avatarLarger, userInfo.avatarLarge, userInfo.profilePictureUrl, userInfo.profilePictureUrls,
        data.profilePictureUrl, data.profile_picture_url, data.profilePictureUrls, data.avatar
    ];

    for (let i = 0; i < candidates.length; i++) {
        const item = candidates[i];
        if (!item) continue;
        if (Array.isArray(item) && item.length > 0 && typeof item[0] === 'string') {
            return item[0];
        }
        if (typeof item === 'string' && (item.startsWith('http://') || item.startsWith('https://'))) {
            return item;
        }
        const arr = (item && (item.urlList || item.url_list || item.urls)) || [];
        if (Array.isArray(arr) && arr.length > 0 && typeof arr[0] === 'string') {
            return arr[0];
        }
    }
    return "";
}

function extractUserIdentity(data) {
    const user = (data && (data.user || data.userDetails || data.userInfo)) || {};
    const details = (data && data.userDetails) || {};
    const userInfo = (data && data.userInfo) || {};
    const username = user.uniqueId || user.displayId || user.username ||
        details.uniqueId || details.displayId || details.username ||
        userInfo.uniqueId || userInfo.displayId || userInfo.username ||
        data?.uniqueId || data?.displayId || data?.username || data?.userId ||
        user.nickname || data?.nickname || "İzleyici";
    return {
        username: String(username).replace(/^@/, ""),
        nickname: user.nickname || details.nickname || userInfo.nickname || data?.nickname || username
    };
}

function avatarDiskKey(username) {
    return ("user_" + String(username || "viewer")).replace(/[^a-zA-Z0-9_.-]/g, "_").slice(0, 120);
}

function readAvatarFromDisk(username) {
    const key = avatarDiskKey(username);
    for (const dir of avatarCacheDirs) {
        try {
            const binPath = path.join(dir, key + ".bin");
            const jsonPath = path.join(dir, key + ".json");
            if (!fs.existsSync(binPath)) continue;
            const buffer = fs.readFileSync(binPath);
            if (buffer.length < 500) continue;
            let contentType = "image/jpeg";
            if (fs.existsSync(jsonPath)) {
                const meta = JSON.parse(fs.readFileSync(jsonPath, "utf8"));
                if (meta.contentType) contentType = meta.contentType;
            }
            return { buffer, contentType };
        } catch (e) {}
    }
    return null;
}

function writeAvatarToDisk(username, result) {
    const key = avatarDiskKey(username);
    for (const dir of avatarCacheDirs) {
        try {
            fs.writeFileSync(path.join(dir, key + ".bin"), result.buffer);
            fs.writeFileSync(path.join(dir, key + ".json"), JSON.stringify({
                contentType: result.contentType,
                zaman: Date.now()
            }));
        } catch (e) {}
    }
}

async function downloadAvatar(url) {
    if (!url || !/^https?:\/\//i.test(url)) return null;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 9000);
    try {
        const response = await fetch(url, {
            signal: controller.signal,
            redirect: "follow",
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36",
                "Referer": "https://www.tiktok.com/",
                "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
                "Accept-Language": "tr-TR,tr;q=0.9,en;q=0.8"
            }
        });
        if (!response.ok) return null;
        const contentType = String(response.headers.get("content-type") || "image/jpeg").split(";")[0];
        if (!contentType.startsWith("image/")) return null;
        const buffer = Buffer.from(await response.arrayBuffer());
        if (buffer.length < 500) return null;
        return { buffer, contentType };
    } catch (e) {
        return null;
    } finally {
        clearTimeout(timer);
    }
}

function findBrowserExecutable() {
    const localAppData = process.env.LOCALAPPDATA || "";
    const candidates = [
        process.env.PUPPETEER_EXECUTABLE_PATH,
        "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
        "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
        "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
        "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
        path.join(localAppData, "Google", "Chrome", "Application", "chrome.exe"),
        path.join(localAppData, "Microsoft", "Edge", "Application", "msedge.exe")
    ];
    return candidates.find(candidate => candidate && fs.existsSync(candidate));
}

async function getAvatarBrowser() {
    if (avatarBrowser && avatarBrowser.connected) return avatarBrowser;
    if (!avatarBrowserPromise) {
        const executablePath = findBrowserExecutable();
        if (!executablePath) throw new Error("Chrome veya Edge bulunamadi.");
        avatarBrowserPromise = puppeteer.launch({
            headless: true,
            executablePath,
            args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage", "--lang=tr-TR,tr"]
        }).then(browser => {
            avatarBrowser = browser;
            avatarBrowserPromise = null;
            return browser;
        }).catch(error => {
            avatarBrowserPromise = null;
            throw error;
        });
    }
    return avatarBrowserPromise;
}

async function convertAvatarToPng(result) {
    if (!result || !/webp|avif/i.test(result.contentType)) return result;
    let page = null;
    try {
        const browser = await getAvatarBrowser();
        page = await browser.newPage();
        const dataUrl = `data:${result.contentType};base64,${result.buffer.toString("base64")}`;
        await page.setViewport({ width: 512, height: 512, deviceScaleFactor: 1 });
        await page.setContent(`<html><body style="margin:0;background:transparent;display:inline-block"><img id="avatar" src="${dataUrl}" style="display:block;max-width:512px;max-height:512px"></body></html>`, { waitUntil: "load", timeout: 10000 });
        await page.waitForFunction(() => {
            const image = document.getElementById("avatar");
            return image && image.complete && image.naturalWidth > 1;
        }, { timeout: 10000 });
        const image = await page.$("#avatar");
        const png = await image.screenshot({ type: "png", omitBackground: true });
        return { buffer: Buffer.from(png), contentType: "image/png" };
    } catch (e) {
        return null;
    } finally {
        if (page) await page.close().catch(() => {});
    }
}

async function findProfileAvatarViaBrowser(username) {
    if (!username) return "";
    let page = null;
    try {
        const browser = await getAvatarBrowser();
        page = await browser.newPage();
        await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36");
        await page.setExtraHTTPHeaders({ "Accept-Language": "tr-TR,tr;q=0.9,en;q=0.8" });
        await page.goto("https://www.tiktok.com/@" + encodeURIComponent(username), { waitUntil: "domcontentloaded", timeout: 20000 });
        const html = await page.content();
        for (const field of ["avatarLarger", "avatarMedium", "avatarThumb"]) {
            const match = html.match(new RegExp('"' + field + '":"([^"]+)"'));
            if (!match) continue;
            try { return JSON.parse('"' + match[1] + '"'); } catch (e) {
                return match[1].replace(/\\u0026/g, "&").replace(/\\\//g, "/");
            }
        }
        await page.waitForSelector('img[src*="-avt-"]', { timeout: 10000 });
        return await page.evaluate(() => {
            const avatars = Array.from(document.images).filter(image => {
                const src = image.currentSrc || image.src || "";
                return src.includes("-avt-") && image.naturalWidth > 1;
            });
            avatars.sort((left, right) => (right.naturalWidth * right.naturalHeight) - (left.naturalWidth * left.naturalHeight));
            return avatars.length > 0 ? (avatars[0].currentSrc || avatars[0].src) : "";
        });
    } catch (e) {
        return "";
    } finally {
        if (page) await page.close().catch(() => {});
    }
    return "";
}

async function resolveAvatar(username, rawUrl) {
    const cacheKey = String(username || "").toLowerCase();
    if (avatarMemoryCache.has(cacheKey)) return avatarMemoryCache.get(cacheKey);

    const diskResult = readAvatarFromDisk(username);
    let result = diskResult ? await convertAvatarToPng(diskResult) : null;
    if (!result) result = await downloadAvatar(rawUrl);
    if ((!result || /webp|avif/i.test(result.contentType)) && username) {
        try {
            const oembedUrl = "https://www.tiktok.com/oembed?url=" + encodeURIComponent("https://www.tiktok.com/@" + username);
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), 7000);
            const response = await fetch(oembedUrl, {
                signal: controller.signal,
                headers: { "User-Agent": "Mozilla/5.0", "Accept-Language": "tr-TR,tr;q=0.9" }
            });
            clearTimeout(timer);
            if (response.ok) {
                const data = await response.json();
                const oembedResult = await downloadAvatar(data.thumbnail_url || "");
                if (oembedResult) result = oembedResult;
            }
        } catch (e) {}
    }
    if (!result) result = diskResult;
    if (!result && username) {
        const browserUrl = await findProfileAvatarViaBrowser(username);
        if (browserUrl) result = await downloadAvatar(browserUrl);
    }
    result = await convertAvatarToPng(result);
    if (result) {
        avatarMemoryCache.set(cacheKey, result);
        if (avatarMemoryCache.size > 500) avatarMemoryCache.delete(avatarMemoryCache.keys().next().value);
        writeAvatarToDisk(username, result);
    }
    return result;
}

function connectToTikTok(username) {
    clearReconnect();
    giftStreakCounts.clear();

    const requestedUsername = String(username || "").replace(/^@/, "").trim();
    if (connection && connectionStatus === "connected" && currentUsername.toLowerCase() === requestedUsername.toLowerCase()) {
        lastError = "";
        return;
    }

    if (connection) {
        try { connection.disconnect(); } catch (e) {}
        connection = null;
    }

    currentUsername = requestedUsername;
    if (!currentUsername) {
        connectionStatus = "disconnected";
        return;
    }

    connectionStatus = "connecting";
    lastError = "";
    console.log(`[TikTok Bridge] Connecting to @${currentUsername}...`);

    connection = new TikTokLiveConnection(currentUsername, {
        processInitialData: false,
        fetchRoomInfoOnConnect: false,
        enableExtendedGiftInfo: false,
        signApiKey: eulerApiKey || undefined
    });

    connection.on("connected", (state) => {
        clearReconnect();
        connectionStatus = "connected";
        lastError = "";
        console.log(`[TikTok Bridge] Connected to @${currentUsername}! Room ID: ${state ? state.roomId : ''}`);
    });

    connection.on("disconnected", () => {
        connectionStatus = "disconnected";
        console.log(`[TikTok Bridge] Disconnected from @${currentUsername}.`);
    });

    connection.on("error", (err) => {
        const msg = err ? (err.info || err.message || (typeof err === 'object' ? JSON.stringify(err) : String(err))) : "";
        if (msg.includes("Room ID") || msg.includes("Failed to retrieve") || msg.includes("user_not_found")) {
            connectionStatus = "offline";
            lastError = `@${currentUsername} şu anda TikTok'ta canlı yayında değil.`;
        } else {
            connectionStatus = "error";
            lastError = msg || "Bağlantı hatası";
        }
        console.error(`[TikTok Bridge] Status:`, connectionStatus, lastError);
    });

    // 1. HEDİYE (GIFT) OLAYI
    connection.on(WebcastEvent.GIFT, (data) => {
        try {
			const identity = extractUserIdentity(data);
			const uId = identity.username;
			const nick = identity.nickname;
            const avatar = extractUserAvatar(data);

            const giftDetails = data.giftDetails || data.gift || {};
            const extendedGift = data.extendedGiftInfo || data.extended_gift_info || {};
            const giftId = String(
                data.giftId || data.gift_id ||
                giftDetails.giftId || giftDetails.gift_id || giftDetails.id ||
                data.gift?.id || data.gift?.giftId || data.gift?.gift_id ||
                extendedGift.id || extendedGift.giftId || extendedGift.gift_id || ""
            );
            const giftName = data.giftName || data.gift_name || data.name ||
                giftDetails.giftName || giftDetails.gift_name || giftDetails.name ||
                data.gift?.name || data.gift?.giftName ||
                extendedGift.name || extendedGift.giftName || "Hediye";
            const repeatCount = Math.max(1, Number(data.repeatCount || data.count) || 1);
            const diamonds = Number(data.diamondCount) || 1;
            const giftType = Number(data.giftType ?? giftDetails.giftType ?? giftDetails.gift_type ?? data.gift?.giftType ?? data.gift?.gift_type ?? 0);
            const giftEventId = [data.groupId, data.orderId, data.logId, data.msgId, data.common?.msgId]
                .map(value => String(value || ""))
                .find(value => value && value !== "0") || "";
            const hasProgressSignal = giftType === 1 || data.repeatEnd !== undefined || !!giftEventId;
            let spawnCount = repeatCount;
            if (hasProgressSignal) {
                const streakKey = giftEventId ? `event:${giftEventId}` : `streak:${uId}:${giftId || giftName}`;
                const previousCount = giftStreakCounts.get(streakKey) || 0;
                spawnCount = Math.max(0, repeatCount - previousCount);
                if (data.repeatEnd) giftStreakCounts.delete(streakKey);
                else {
                    giftStreakCounts.set(streakKey, Math.max(previousCount, repeatCount));
                    setTimeout(() => giftStreakCounts.delete(streakKey), 30000);
                }
                if (spawnCount < 1) return;
            }

            console.log(`[TikTok Bridge] 🎁 GIFT received: ${uId} sent +${spawnCount} ${giftName} (ID: ${giftId})`);

            queueEvent({
                eventType: "gift",
                username: uId,
                nickname: nick,
                avatarUrl: avatar,
                giftId: giftId,
                giftName: giftName,
                repeatCount: spawnCount,
                diamondCount: diamonds,
                timestamp: Date.now()
            });
            widgetGiftPost({ username: uId, nickname: nick, avatar, giftName, count: spawnCount, repeatCount: spawnCount, coins: diamonds * spawnCount });
        } catch (err) {
            console.error("[TikTok Bridge] Error parsing gift:", err);
        }
    });

    // 2. BEĞENİ (LIKE) OLAYI
    if (WebcastEvent.LIKE) {
        connection.on(WebcastEvent.LIKE, (data) => {
            try {
				const identity = extractUserIdentity(data);
				const uId = identity.username;
				const nick = identity.nickname;
                const avatar = extractUserAvatar(data);
                const likeCount = Math.max(1, Number(data.count ?? data.likeCount ?? 1) || 1);

                console.log(`[TikTok Bridge] ❤️ LIKE: ${uId} x${likeCount} beğeni gönderdi`);

                queueEvent({
                    eventType: "like",
                    username: uId,
                    nickname: nick,
                    avatarUrl: avatar,
                    repeatCount: likeCount,
                    timestamp: Date.now()
                });
                widgetLikePost({ username: uId, nickname: nick, avatar, likeCount });
            } catch (err) {
                console.error("[TikTok Bridge] Error parsing like:", err);
            }
        });
    }

    // 3. TAKİP (FOLLOW) OLAYI
    if (WebcastEvent.FOLLOW) {
        connection.on(WebcastEvent.FOLLOW, (data) => {
            try {
				const identity = extractUserIdentity(data);
				const uId = identity.username;
				const nick = identity.nickname;
                const avatar = extractUserAvatar(data);
				if (!shouldQueueFollow(uId)) return;

                console.log(`[TikTok Bridge] 👤 FOLLOW: ${uId} yayını takip etti`);

                queueEvent({
                    eventType: "follow",
                    username: uId,
                    nickname: nick,
                    avatarUrl: avatar,
                    repeatCount: 1,
                    timestamp: Date.now()
                });
            } catch (err) {
                console.error("[TikTok Bridge] Error parsing follow:", err);
            }
        });
    }

    // 4. SOCIAL (FOLLOW ALTERNATİFİ)
    if (WebcastEvent.SOCIAL) {
        connection.on(WebcastEvent.SOCIAL, (data) => {
            try {
                const action = String(data.displayType || data.action || data.label || "").toLowerCase();
                if (!action.includes("follow")) return;

				const identity = extractUserIdentity(data);
				const uId = identity.username;
				const nick = identity.nickname;
                const avatar = extractUserAvatar(data);
				if (!shouldQueueFollow(uId)) return;

                console.log(`[TikTok Bridge] 👤 SOCIAL FOLLOW: ${uId}`);

                queueEvent({
                    eventType: "follow",
                    username: uId,
                    nickname: nick,
                    avatarUrl: avatar,
                    repeatCount: 1,
                    timestamp: Date.now()
                });
            } catch (err) {}
        });
    }

    connection.connect().then(() => {
        clearReconnect();
        connectionStatus = "connected";
        lastError = "";
    }).catch((err) => {
        const msg = err ? (err.info || err.message || (typeof err === 'object' ? JSON.stringify(err) : String(err))) : "";
        if (msg.includes("Room ID") || msg.includes("Failed to retrieve") || msg.includes("user_not_found")) {
            connectionStatus = "offline";
            lastError = `@${currentUsername} şu anda yayında değil.`;
            console.log(`[TikTok Bridge] User @${currentUsername} is offline. Waiting for a manual connect request.`);
        } else {
            connectionStatus = "error";
            lastError = msg || "Bağlantı kurulamadı";
            console.error(`[TikTok Bridge] Connect failed:`, lastError);
        }
    });
}

const server = http.createServer(async (req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.setHeader("Content-Type", "application/json; charset=utf-8");

    const parsedUrl = new URL(req.url, `http://localhost:${PORT}`);
    const pathname = parsedUrl.pathname;

    if (pathname === "/avatar") {
        const username = String(parsedUrl.searchParams.get("user") || "").replace(/^@/, "").trim();
        const rawUrl = parsedUrl.searchParams.get("url") || "";
        const result = await resolveAvatar(username, rawUrl);
        if (!result) {
            res.statusCode = 404;
            return res.end(JSON.stringify({ ok: false, error: "avatar_not_found" }));
        }
        res.statusCode = 200;
        res.setHeader("Content-Type", result.contentType);
        res.setHeader("Cache-Control", "public, max-age=600");
        return res.end(result.buffer);
    } else if (pathname === "/status") {
        res.end(JSON.stringify({
            bridgeVersion: BRIDGE_VERSION,
            status: connectionStatus,
			connected: connectionStatus === "connected",
            username: currentUsername,
			roomUser: currentUsername,
            lastError: lastError,
            queuedCount: eventQueue.length
        }));
    } else if (pathname === "/connect") {
        const username = parsedUrl.searchParams.get("username") || "";
        connectToTikTok(username);
        res.end(JSON.stringify({
            ok: true,
            status: connectionStatus,
            username: currentUsername
        }));
    } else if (pathname === "/disconnect") {
        clearReconnect();
        giftStreakCounts.clear();
        if (connection) {
            try { connection.disconnect(); } catch (e) {}
            connection = null;
        }
        connectionStatus = "disconnected";
        currentUsername = "";
        lastError = "";
        res.end(JSON.stringify({ ok: true, status: "disconnected" }));
    } else if (pathname === "/shutdown") {
        clearReconnect();
        giftStreakCounts.clear();
        if (connection) {
            try { connection.disconnect(); } catch (e) {}
            connection = null;
        }
        connectionStatus = "disconnected";
        currentUsername = "";
        lastError = "";
        eventQueue.length = 0;
        res.end(JSON.stringify({ ok: true, status: "shutting_down" }));
        setTimeout(() => server.close(() => process.exit(0)), 25);
    } else if (pathname === "/events") {
        const events = eventQueue.splice(0);
        res.end(JSON.stringify({
            events: events,
            status: connectionStatus,
            username: currentUsername
        }));
    } else if (pathname === "/test-gift") {
        const gift = parsedUrl.searchParams.get("gift") || "Rose";
        const count = parseInt(parsedUrl.searchParams.get("count") || "1", 10);
        const user = parsedUrl.searchParams.get("user") || "TestUser";
        const giftId = parsedUrl.searchParams.get("giftId") || "5655";
        queueEvent({
            eventType: "gift",
            username: user,
            nickname: user,
            avatarUrl: "",
            giftId: giftId,
            giftName: gift,
            repeatCount: count,
            diamondCount: 1,
            timestamp: Date.now()
        });
        res.end(JSON.stringify({ ok: true, queued: gift, count }));
    } else if (pathname === "/test-like") {
        const count = parseInt(parsedUrl.searchParams.get("count") || "100", 10);
        const user = parsedUrl.searchParams.get("user") || "TestUser";
        queueEvent({
            eventType: "like",
            username: user,
            nickname: user,
            avatarUrl: "",
            repeatCount: count,
            timestamp: Date.now()
        });
        res.end(JSON.stringify({ ok: true, queued: "like", count }));
    } else if (pathname === "/test-follow") {
        const user = parsedUrl.searchParams.get("user") || "TestUser";
        queueEvent({
            eventType: "follow",
            username: user,
            nickname: user,
            avatarUrl: "",
            repeatCount: 1,
            timestamp: Date.now()
        });
        res.end(JSON.stringify({ ok: true, queued: "follow" }));
    } else {
        res.end(JSON.stringify({ ok: true, msg: "TikTok-Unturned Bridge is running" }));
    }
});

server.listen(PORT, "127.0.0.1", () => {
    console.log(`[TikTok Bridge] Server listening on http://127.0.0.1:${PORT}`);
});
