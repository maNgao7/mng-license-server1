// ==========================================================================
// SES YÖNETİCİSİ
// public/sounds/ klasörüne aşağıdaki adlarla .mp3 / .ogg / .wav dosyası
// koyulduğunda otomatik olarak o dosya çalınır; yoksa sentez ses kullanılır.
//   kick, goal, save, post, miss, whistle, crowd, cheer, ooh, gift,
//   keeper, jersey, wall, tsubasa, shrink, net, ui
// ==========================================================================

const SOUND_NAMES = ['kick', 'goal', 'save', 'post', 'miss', 'whistle', 'crowd', 'cheer', 'ooh', 'gift',
  'keeper', 'jersey', 'wall', 'tsubasa', 'shrink', 'net', 'ui'];
const EXTENSIONS = ['mp3', 'ogg', 'wav'];

export class SoundManager {
  constructor() {
    this.ctx = null;
    this.enabled = true;
    this.master = null;
    this.buffers = {};
    this.crowdNode = null;
    this.probed = false;
    this.volume = 0.8;
  }

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') this.ctx.resume();
      if (this.buffers.crowd && !this.crowdNode) this.startCrowdLoop();
      return;
    }
    try {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.8;
      this.master.connect(this.ctx.destination);
      this.probeFiles();
    } catch (e) {
      console.warn('Ses başlatılamadı', e);
    }
  }

  async probeFiles() {
    if (this.probed) return;
    this.probed = true;
    let list = ['goal.mp3', 'crowd.mp3'];
    try {
      const res = await fetch('/api/sounds');
      if (res.ok) {
        const fetched = await res.json();
        if (Array.isArray(fetched) && fetched.length) list = fetched;
      }
    } catch {}
    for (const name of SOUND_NAMES) {
      const file = EXTENSIONS.map(ext => `${name}.${ext}`).find(f => list.includes(f));
      if (!file) continue;
      try {
        const res = await fetch(`/sounds/${file}`);
        const arr = await res.arrayBuffer();
        this.buffers[name] = await this.ctx.decodeAudioData(arr);
      } catch {}
    }
    if (this.buffers.crowd) this.startCrowdLoop();
  }

  setVolume(pct) {
    const v = Math.max(0, Math.min(100, Number(pct) || 0)) / 100;
    this.volume = v;
    if (this.master) {
      this.master.gain.value = this.enabled ? v : 0;
    }
  }

  setEnabled(v) {
    this.enabled = Boolean(v);
    if (this.master) this.master.gain.value = this.enabled ? (this.volume ?? 0.8) : 0;
  }

  startCrowdLoop() {
    if (!this.ctx || !this.buffers.crowd || this.crowdNode) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.buffers.crowd;
    src.loop = true;
    const g = this.ctx.createGain();
    g.gain.value = 0.35;
    src.connect(g).connect(this.master);
    src.start();
    this.crowdNode = src;
  }

  play(name, opts = {}) {
    if (!this.ctx || !this.enabled) return;
    if (this.buffers[name]) {
      const src = this.ctx.createBufferSource();
      src.buffer = this.buffers[name];
      const g = this.ctx.createGain();
      g.gain.value = opts.volume ?? 1;
      src.connect(g).connect(this.master);
      src.start();
      return;
    }
    const fn = this['synth_' + name];
    if (fn) fn.call(this, opts);
  }

  // ---------------- Sentez sesler (geçici) ----------------
  tone(freq, dur, type = 'sine', vol = 0.2, slideTo = null, delay = 0) {
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  noise(dur, vol = 0.2, filterFreq = 1200, delay = 0, q = 0.7) {
    const t = this.ctx.currentTime + delay;
    const len = Math.floor(this.ctx.sampleRate * dur);
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const f = this.ctx.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = filterFreq;
    f.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + Math.min(0.25, dur * 0.3));
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f).connect(g).connect(this.master);
    src.start(t);
  }

  synth_kick(o) { this.tone(140, 0.12, 'sine', 0.5, 50); this.noise(0.08, 0.25, 2500); if (o.fire) this.noise(0.6, 0.25, 600); }
  synth_whistle() {
    // Düdük sesi tamamen kaldırıldı (Kullanıcı talebi doğrultusunda sessizleştirildi)
    return;
  }
  synth_goal() { this.noise(3.2, 0.45, 900, 0, 0.4); [523, 659, 784, 1047].forEach((f, i) => this.tone(f, 0.35, 'triangle', 0.12, null, i * 0.11)); }
  synth_cheer() { this.noise(2.5, 0.35, 1000, 0, 0.4); }
  synth_save() { this.tone(180, 0.15, 'sine', 0.4, 90); this.noise(1.6, 0.28, 500, 0.05, 0.5); }
  synth_ooh() { this.noise(1.4, 0.3, 420, 0, 0.6); }
  synth_post() { this.tone(1250, 0.6, 'triangle', 0.2, 1180); this.tone(1870, 0.45, 'sine', 0.08); }
  synth_miss() { this.noise(1.4, 0.3, 380, 0, 0.6); }
  synth_net() { this.noise(0.35, 0.18, 3000); }
  synth_gift() { [880, 1175, 1568].forEach((f, i) => this.tone(f, 0.18, 'sine', 0.1, null, i * 0.07)); }
  synth_keeper() { this.tone(330, 0.2, 'sawtooth', 0.08, 660); this.tone(660, 0.3, 'triangle', 0.1, null, 0.15); }
  synth_jersey() { [392, 523, 659, 784].forEach((f, i) => this.tone(f, 0.22, 'triangle', 0.12, null, i * 0.08)); }
  synth_wall() { this.tone(110, 0.3, 'square', 0.12, 80); this.tone(110, 0.3, 'square', 0.12, 80, 0.18); }
  synth_tsubasa() { this.tone(200, 0.8, 'sawtooth', 0.12, 1200); this.noise(0.9, 0.2, 700); }
  synth_shrink() { this.tone(1200, 0.5, 'sine', 0.12, 200); }
  synth_ui() { this.tone(900, 0.06, 'sine', 0.06); }
}
