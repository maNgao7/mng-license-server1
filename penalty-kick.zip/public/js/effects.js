// ==========================================================================
// EFEKTLER VE PARÇACIKLAR - Konfeti, Tsubasa Alev Şutu, Çim Tozu
// ==========================================================================
import * as THREE from 'three';

export class EffectsManager {
  constructor(scene) {
    this.scene = scene;
    this.particles = [];
    this.firePool = [];
    this.confettiPool = [];
  }

  // 1. Gol Kutlaması Konfeti Patlaması
  spawnConfetti(colorHex1 = '#ffd700', colorHex2 = '#ff0033', count = 180) {
    const geo = new THREE.PlaneGeometry(0.12, 0.18);
    const colors = [colorHex1, colorHex2, '#ffffff', '#00e5ff', '#a855f7', '#10b981'];

    for (let i = 0; i < count; i++) {
      const c = colors[Math.floor(Math.random() * colors.length)];
      const mat = new THREE.MeshBasicMaterial({
        color: new THREE.Color(c),
        side: THREE.DoubleSide
      });
      const mesh = new THREE.Mesh(geo, mat);

      // Kale önünden yukarı ve dışarı doğru patlama
      const x = (Math.random() - 0.5) * 6.0;
      const y = 1.0 + Math.random() * 2.0;
      const z = (Math.random() - 0.5) * 2.0;
      mesh.position.set(x, y, z);

      mesh.rotation.set(
        Math.random() * Math.PI,
        Math.random() * Math.PI,
        Math.random() * Math.PI
      );

      const vx = (Math.random() - 0.5) * 7.0;
      const vy = 5.0 + Math.random() * 8.0;
      const vz = (Math.random() - 0.5) * 6.0;

      const p = {
        mesh,
        vel: new THREE.Vector3(vx, vy, vz),
        rotVel: new THREE.Vector3(Math.random() * 10, Math.random() * 10, Math.random() * 10),
        life: 1.0,
        decay: 0.25 + Math.random() * 0.2
      };

      this.scene.add(mesh);
      this.particles.push(p);
    }
  }

  // 2. Tsubasa Alevli Şut Parçacıkları (Topun arkasından süzülen devasa alev fırtınası)
  spawnFireTail(pos, count = 4) {
    const fireColors = ['#ffffff', '#fffa65', '#ff9f1c', '#ff3838', '#c92a2a'];
    const geo = new THREE.SphereGeometry(0.12, 8, 8);

    for (let i = 0; i < count; i++) {
      const c = fireColors[Math.floor(Math.random() * fireColors.length)];
      const mat = new THREE.MeshBasicMaterial({
        color: new THREE.Color(c),
        transparent: true,
        opacity: 0.95,
        blending: THREE.AdditiveBlending
      });
      const mesh = new THREE.Mesh(geo, mat);

      mesh.position.copy(pos);
      mesh.position.x += (Math.random() - 0.5) * 0.22;
      mesh.position.y += (Math.random() - 0.5) * 0.22;
      mesh.position.z += (Math.random() - 0.5) * 0.22;

      const p = {
        mesh,
        vel: new THREE.Vector3(
          (Math.random() - 0.5) * 1.5,
          1.2 + Math.random() * 2.2,
          (Math.random() - 0.5) * 1.5
        ),
        rotVel: new THREE.Vector3(),
        life: 1.0,
        decay: 3.2,
        isFire: true
      };

      this.scene.add(mesh);
      this.particles.push(p);
    }
  }

  // 2b. Tsubasa Top Başında Beklerken Çıkan Alev Parçacıkları (Olduğu yerde alev dalgası)
  spawnFireAura(pos) {
    const fireColors = ['#fffa65', '#ff9f1c', '#ff3838'];
    const geo = new THREE.SphereGeometry(0.08, 6, 6);
    const c = fireColors[Math.floor(Math.random() * fireColors.length)];
    const mat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(c),
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending
    });
    const mesh = new THREE.Mesh(geo, mat);

    mesh.position.copy(pos);
    mesh.position.x += (Math.random() - 0.5) * 0.18;
    mesh.position.y += Math.random() * 0.15;
    mesh.position.z += (Math.random() - 0.5) * 0.18;

    const p = {
      mesh,
      vel: new THREE.Vector3(
        (Math.random() - 0.5) * 0.4,
        0.8 + Math.random() * 1.2,
        (Math.random() - 0.5) * 0.4
      ),
      rotVel: new THREE.Vector3(),
      life: 0.8,
      decay: 2.8,
      isFire: true
    };

    this.scene.add(mesh);
    this.particles.push(p);
  }

  // 3. Şut Vurulduğunda Çim Tozu Patlaması
  spawnKickDust(pos) {
    const geo = new THREE.SphereGeometry(0.06, 6, 6);
    const dustMat = new THREE.MeshBasicMaterial({
      color: 0x88cc88,
      transparent: true,
      opacity: 0.6
    });

    for (let i = 0; i < 14; i++) {
      const mesh = new THREE.Mesh(geo, dustMat);
      mesh.position.copy(pos);

      const angle = Math.random() * Math.PI * 2;
      const speed = 1.0 + Math.random() * 2.5;

      const p = {
        mesh,
        vel: new THREE.Vector3(Math.cos(angle) * speed, 0.4 + Math.random() * 1.2, Math.sin(angle) * speed),
        rotVel: new THREE.Vector3(),
        life: 1.0,
        decay: 2.2
      };

      this.scene.add(mesh);
      this.particles.push(p);
    }
  }

  // 4. Şık Hız & Rüzgar Akımı İzi (Videodaki gibi topun arkasında zarif beyaz hava izi)
  spawnBallTrail(pos) {
    const geo = new THREE.SphereGeometry(0.065, 8, 8);
    const mat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.55
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(pos);
    mesh.position.x += (Math.random() - 0.5) * 0.05;
    mesh.position.y += (Math.random() - 0.5) * 0.05;

    const p = {
      mesh,
      vel: new THREE.Vector3((Math.random() - 0.5) * 0.1, (Math.random() - 0.5) * 0.1, 0.4),
      rotVel: new THREE.Vector3(),
      life: 1.0,
      decay: 4.8,
      isFire: true // küçülerek ve solarak kaybolur
    };

    this.scene.add(mesh);
    this.particles.push(p);
  }

  update(dt) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= p.decay * dt;

      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        p.mesh.geometry.dispose();
        p.mesh.material.dispose();
        this.particles.splice(i, 1);
        continue;
      }

      // Hareket & Yerçekimi
      p.mesh.position.addScaledVector(p.vel, dt);

      if (!p.isFire) {
        p.vel.y -= 9.8 * dt; // Yerçekimi
      } else {
        // Alev küçülerek yok olur
        const s = Math.max(0.01, p.life);
        p.mesh.scale.set(s, s, s);
        p.mesh.material.opacity = p.life * 0.95;
      }

      p.mesh.rotation.x += p.rotVel.x * dt;
      p.mesh.rotation.y += p.rotVel.y * dt;
      p.mesh.rotation.z += p.rotVel.z * dt;
    }
  }

  clear() {
    this.particles.forEach(p => {
      this.scene.remove(p.mesh);
      p.mesh.geometry.dispose();
      p.mesh.material.dispose();
    });
    this.particles = [];
  }
}
