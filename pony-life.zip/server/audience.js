import { keyOf } from '../shared/race.js';

export class Audience {
  constructor({ capacity = 100, ttl = 120000 } = {}) { this.capacity = capacity; this.ttl = ttl; this.people = new Map(); }
  touch(profile, kind = 'member', count = 0, now = Date.now()) {
    if (!profile) return;
    const id = keyOf(profile.id || profile.username); if (!id) return;
    this.prune(now);
    let p = this.people.get(id);
    if (!p) {
      if (this.people.size >= this.capacity) { const oldest = [...this.people.values()].sort((a,b) => a.seenAt-b.seenAt)[0]; this.people.delete(oldest.id); }
      p = { ...profile, id, likePulse:0, likedAt:0, seenAt:now }; this.people.set(id,p);
    }
    if (profile.avatar && (profile.avatarQuality || 1) >= (p.avatarQuality || 1)) { p.avatar=profile.avatar; p.avatarQuality=profile.avatarQuality; }
    p.seenAt=now;
    if (kind === 'like' && count > 0) { p.likePulse++; p.likedAt=now; }
  }
  leave(id) { this.people.delete(keyOf(id)); }
  clear() { this.people.clear(); }
  prune(now) { for (const [id,p] of this.people) if (now-p.seenAt > this.ttl) this.people.delete(id); }
  snapshot(now = Date.now()) { this.prune(now); return [...this.people.values()]; }
}
