import express from "express";
import http from "http";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { WebSocketServer } from "ws";
import { WebcastPushConnection } from "tiktok-live-connector";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT || 3030);

const app = express();
app.use(express.static(path.join(__dirname, "public"), {
  etag: false,
  lastModified: false,
  setHeaders: (res) => {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  }
}));

app.use("/catalog-assets", express.static(path.join(__dirname, "..", "tiktok-vs", "public", "assets"), {
  maxAge: "30d",
  immutable: true
}));

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

// Avatar önbelleği
const avatarCache = new Map();
const AVATAR_HOSTS = ["tiktokcdn.com", "byteimg.com", "ibytedtos.com", "tiktokv.com", "pravatar.cc", "unavatar.io"];
const LAUNCHER_AVATAR_CACHE = path.join(__dirname, "..", "tiktok-vs", ".avatar-cache");

// Hediye Kataloğu
const TAM_KATALOG_PATH = path.join(__dirname, "..", "tiktok-vs", "public", "assets", "gift-images", "katalog_tam.json");
let giftCatalog = [];
try {
  if (fs.existsSync(TAM_KATALOG_PATH)) {
    const raw = JSON.parse(fs.readFileSync(TAM_KATALOG_PATH, "utf8"));
    if (Array.isArray(raw)) {
      raw.sort((a, b) => (Number(a.coins) || 0) - (Number(b.coins) || 0));
      giftCatalog = raw.map(g => ({
        id: String(g.id || g.name),
        name: g.trName || g.name,
        origName: g.name,
        coins: Number(g.coins) || 1,
        image: g.image || `/catalog-assets/gift-images/${g.file}`
      }));
    }
  }
} catch (e) {
  console.warn("Katalog okunamadı:", e.message);
}

// Health check endpoint (Launcher doğrulama için)
app.get("/api/health", (_req, res) => {
  res.json({ ok: true, app: "mng-battle-game", port: PORT, gifts: giftCatalog.length });
});

// Hediye listesi
app.get("/api/gifts", (_req, res) => {
  const query = String(_req.query.query || "").trim().toLowerCase();
  const limit = Math.max(24, Math.min(Number(_req.query.limit) || 650, 700));
  if (!query) {
    return res.json(giftCatalog.slice(0, limit));
  }
  const filtered = giftCatalog.filter(g =>
    g.name.toLowerCase().includes(query) ||
    (g.origName && g.origName.toLowerCase().includes(query)) ||
    String(g.coins).includes(query)
  );
  res.json(filtered.slice(0, limit));
});

// Avatar proxy
function createInitialSvg(username, size = 64) {
  const letter = String(username || "U").replace(/^@/, "").charAt(0).toUpperCase() || "U";
  let hash = 0;
  for (let i = 0; i < username.length; i++) hash = (hash * 31 + username.charCodeAt(i)) & 0xffffffff;
  const hue = Math.abs(hash) % 360;
  return `<?xml version="1.0" encoding="UTF-8"?><svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}" fill="hsl(${hue}, 70%, 45%)"/><text x="50%" y="54%" text-anchor="middle" dominant-baseline="middle" fill="#ffffff" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="${Math.round(size * 0.44)}" font-weight="700">${letter}</text></svg>`;
}

app.get("/api/avatar", async (req, res) => {
  const rawUrl = String(req.query.url || "").trim();
  const rawUser = String(req.query.user || "").trim() || "oyuncu";
  if (!rawUrl) {
    res.setHeader("Content-Type", "image/svg+xml");
    return res.send(createInitialSvg(rawUser));
  }
  if (avatarCache.has(rawUrl)) {
    const cached = avatarCache.get(rawUrl);
    res.setHeader("Content-Type", cached.contentType || "image/jpeg");
    res.setHeader("Cache-Control", "public, max-age=86400");
    return res.send(cached.buffer);
  }
  try {
    const u = new URL(rawUrl);
    if (!AVATAR_HOSTS.some(h => u.hostname === h || u.hostname.endsWith("." + h))) {
      throw new Error("Geçersiz avatar hostu");
    }
    const response = await fetch(rawUrl, { headers: { "User-Agent": "Mozilla/5.0" } });
    if (!response.ok) throw new Error("Avatar çekilemedi");
    const arr = await response.arrayBuffer();
    const buffer = Buffer.from(arr);
    const contentType = response.headers.get("content-type") || "image/jpeg";
    avatarCache.set(rawUrl, { buffer, contentType });
    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "public, max-age=86400");
    return res.send(buffer);
  } catch {
    res.setHeader("Content-Type", "image/svg+xml");
    return res.send(createInitialSvg(rawUser));
  }
});

// TikTok Bağlantı Yönetimi
let tiktokLive = null;
let currentUsername = "";
const tournamentWinners = new Map();

function tournamentEntries() {
  return [...tournamentWinners.values()]
    .filter(entry => entry.count > 0)
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name))
    .slice(0, 20);
}

function broadcast(msg) {
  const str = typeof msg === "string" ? msg : JSON.stringify(msg);
  wss.clients.forEach(c => {
    if (c.readyState === 1) c.send(str);
  });
}

function broadcastTournament() {
  broadcast({ type: "tournament-winners", entries: tournamentEntries() });
}

function connectToTikTok(user) {
  const clean = String(user || "").replace(/^@/, "").trim();
  if (!clean) return;
  if (tiktokLive) {
    try { tiktokLive.disconnect(); } catch {}
    tiktokLive = null;
  }
  currentUsername = clean;
  broadcast({ type: "status", status: "connecting", username: clean });

  const tt = new WebcastPushConnection(clean, {
    processInitialData: false,
    enableExtendedGiftInfo: true,
    requestPollingIntervalMs: 1000,
    clientParams: { app_language: "tr-TR", device_platform: "web" }
  });

  tt.connect()
    .then(state => {
      tiktokLive = tt;
      broadcast({ type: "status", status: "connected", roomId: state.roomId, username: clean });
    })
    .catch(err => {
      broadcast({ type: "status", status: "error", error: err.message, username: clean });
    });

  tt.on("gift", data => {
    const coins = Number(data.diamondCount) || 1;
    const count = Number(data.repeatCount) || 1;
    const totalCoins = coins * count;
    const giftName = data.giftName || "Hediye";
    const giftId = String(data.giftId || "");
    const avatar = (data.profilePictureUrl || (data.userDetails && data.userDetails.profilePictureUrls && data.userDetails.profilePictureUrls[0])) || "";

    broadcast({
      type: "gift",
      player: {
        id: data.userId || data.uniqueId,
        nickname: data.nickname || data.uniqueId,
        username: data.uniqueId,
        avatar: avatar ? `/api/avatar?url=${encodeURIComponent(avatar)}&user=${encodeURIComponent(data.uniqueId)}` : ""
      },
      giftId,
      giftName,
      coins: totalCoins,
      unitCoins: coins,
      count
    });
  });

  tt.on("streamEnd", () => {
    broadcast({ type: "status", status: "streamEnd", username: clean });
  });

  tt.on("disconnected", () => {
    broadcast({ type: "status", status: "disconnected", username: clean });
  });
}

wss.on("connection", ws => {
  ws.send(JSON.stringify({
    type: "init",
    status: tiktokLive ? "connected" : "idle",
    username: currentUsername
  }));
  ws.send(JSON.stringify({ type: "tournament-winners", entries: tournamentEntries() }));

  ws.on("message", raw => {
    try {
      const data = JSON.parse(raw);
      if (data.type === "connect" && data.username) {
        connectToTikTok(data.username);
      } else if (data.type === "disconnect") {
        if (tiktokLive) {
          try { tiktokLive.disconnect(); } catch {}
          tiktokLive = null;
        }
        currentUsername = "";
        broadcast({ type: "status", status: "disconnected" });
      } else if (data.type === "simulate-gift") {
        broadcast({
          type: "gift",
          player: data.player || { nickname: "Test Oyuncu", username: "test_user", avatar: "" },
          giftId: data.giftId || "5655",
          giftName: data.giftName || "Gül",
          coins: data.coins || 10,
          count: 1
        });
      } else if (data.type === "tournament-win" && data.player) {
        const player = data.player;
        const id = String(player.id || player.name || player.username || "").trim();
        if (!id) return;
        const current = tournamentWinners.get(id) || {
          id,
          name: String(player.name || player.username || id).slice(0, 80),
          avatar: String(player.avatar || "").slice(0, 2000),
          count: 0
        };
        current.count = Math.max(0, current.count + (Number(data.delta) || 1));
        current.name = String(player.name || player.username || current.name).slice(0, 80);
        if (player.avatar) current.avatar = String(player.avatar).slice(0, 2000);
        tournamentWinners.set(id, current);
        broadcastTournament();
      } else if (data.type === "tournament-reset") {
        tournamentWinners.clear();
        broadcastTournament();
      }
    } catch {}
  });
});

server.listen(PORT, () => {
  console.log(`MNG Şövalye Savaşı sunucusu çalışıyor: http://localhost:${PORT}`);
});
