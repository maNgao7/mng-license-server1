import express from "express";
import http from "http";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { WebSocketServer } from "ws";
import { TikTokLiveConnection, WebcastEvent } from "tiktok-live-connector";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT || 3040);
const WIDGET_PORT = 31975;

function widgetGiftPost(payload) {
  try {
    const body = JSON.stringify(payload);
    const req = http.request({
      hostname: "127.0.0.1",
      port: WIDGET_PORT,
      path: "/api/widget/gift",
      method: "POST",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) },
      timeout: 800
    }, () => {});
    req.on("error", () => {});
    req.end(body);
  } catch {}
}

function widgetLikePost(payload) {
  try {
    const body = JSON.stringify(payload);
    const req = http.request({
      hostname: "127.0.0.1",
      port: WIDGET_PORT,
      path: "/api/widget/like",
      method: "POST",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) },
      timeout: 800
    }, () => {});
    req.on("error", () => {});
    req.end(body);
  } catch {}
}

const app = express();
app.use(express.static(path.join(__dirname, "public")));

function findCatalogPath() {
  const candidates = [
    path.join(__dirname, "..", "tiktok-vs", "public", "assets"),
    path.join(__dirname, "..", "MNG-TikTok-Game", "apps", "tiktok-vs", "public", "assets"),
    path.join("C:", "Users", "User", "Desktop", "MNG-TikTok-Game", "apps", "tiktok-vs", "public", "assets")
  ];
  return candidates.find(p => fs.existsSync(p)) || path.join(__dirname, "public");
}

function findSharedBackgroundsPath() {
  const candidates = [
    path.join(__dirname, "..", "tiktok-vs", "public", "assets", "backgrounds"),
    path.join(__dirname, "..", "MNG-TikTok-Game", "apps", "tiktok-vs", "public", "assets", "backgrounds"),
    path.join("C:", "Users", "User", "Desktop", "MNG-TikTok-Game", "apps", "tiktok-vs", "public", "assets", "backgrounds")
  ];
  return candidates.find(p => fs.existsSync(p)) || path.join(__dirname, "public");
}

function findAvatarCachePath() {
  const candidates = [
    path.join(__dirname, "..", "tiktok-vs", ".avatar-cache"),
    path.join(__dirname, "..", "MNG-TikTok-Game", "apps", "tiktok-vs", ".avatar-cache"),
    path.join("C:", "Users", "User", "Desktop", "MNG-TikTok-Game", "apps", "tiktok-vs", ".avatar-cache")
  ];
  return candidates.find(p => fs.existsSync(p)) || path.join(__dirname, ".avatar-cache");
}

app.use("/catalog-assets", express.static(findCatalogPath(), { maxAge: "30d", immutable: true }));
app.use("/shared-backgrounds", express.static(findSharedBackgroundsPath()));

app.get("/api/catalog", (_req, res) => {
  const localCatalog = path.join(__dirname, "gift-catalog.json");
  if (fs.existsSync(localCatalog)) {
    try {
      const data = JSON.parse(fs.readFileSync(localCatalog, "utf8"));
      if (Array.isArray(data) && data.length) {
        return res.json(data);
      }
    } catch {}
  }

  const giftDir = path.join(findCatalogPath(), "gift-images");
  const p = path.join(giftDir, "_kutuphane.json");
  let items = [];

  if (fs.existsSync(p)) {
    try {
      const data = JSON.parse(fs.readFileSync(p, "utf8"));
      if (Array.isArray(data) && data.length) items = data;
    } catch {}
  }

  // Fallback / complement from directory scan to guarantee 100% of gift png files
  if (fs.existsSync(giftDir)) {
    try {
      const existingFiles = new Set(items.map(x => (x.file || '').toLowerCase()));
      const files = fs.readdirSync(giftDir).filter(f => f.endsWith(".png") && !f.startsWith("."));
      files.forEach(f => {
        if (!existingFiles.has(f.toLowerCase())) {
          items.push({
            name: f.replace(/\.png$/i, "").replace(/_/g, " "),
            file: f,
            coins: 1,
            duplicate_image: false
          });
        }
      });
    } catch {}
  }

  res.json(items);
});

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

const avatarCache = new Map();
const AVATAR_HOSTS = ["tiktokcdn.com", "byteimg.com", "ibytedtos.com", "tiktokv.com", "pravatar.cc", "unavatar.io"];
const LAUNCHER_AVATAR_CACHE = findAvatarCachePath();

let connection = null;
let activeUsername = "";
let topScores = [];

function eulerKey() {
  const candidates = [
    path.join(__dirname, "euler-api-key.txt"),
    path.join(__dirname, "..", "tiktok-vs", "euler-api-key.txt"),
    path.join(__dirname, "..", "mng-orbit", "euler-api-key.txt"),
    path.join(__dirname, "..", "crowd-control", "euler-api-key.txt"),
    path.join("C:", "Users", "User", "Desktop", "MNG-TikTok-Game", "apps", "tiktok-vs", "euler-api-key.txt")
  ];
  for (const c of candidates) {
    try {
      if (fs.existsSync(c)) {
        const val = fs.readFileSync(c, "utf8").trim();
        if (val) return val;
      }
    } catch {}
  }
  return undefined;
}

function trustedAvatarUrl(rawUrl) {
  if (!rawUrl || typeof rawUrl !== "string") return null;
  try {
    const parsed = new URL(rawUrl.trim());
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
    const hostname = parsed.hostname.toLowerCase();
    const isAllowed = AVATAR_HOSTS.some(host => hostname === host || hostname.endsWith(`.${host}`));
    return isAllowed ? parsed : null;
  } catch {
    return null;
  }
}

function uretVarsayilanAvatarSvg(username) {
  const clean = String(username || "U").trim();
  const harf = (clean.charAt(0) || "U").toUpperCase();
  const renkler = [
    "#f59e0b", "#ef4444", "#3b82f6", "#10b981", "#8b5cf6",
    "#ec4899", "#06b6d4", "#84cc16", "#f97316", "#6366f1"
  ];
  let h = 0;
  for (let i = 0; i < clean.length; i++) h = (h * 31 + clean.charCodeAt(i)) >>> 0;
  const bg = renkler[h % renkler.length];
  return `<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128">
    <circle cx="64" cy="64" r="64" fill="${bg}"/>
    <text x="64" y="80" font-size="64" font-weight="900" font-family="system-ui, -apple-system, sans-serif" fill="#ffffff" text-anchor="middle" dominant-baseline="central">${harf}</text>
  </svg>`;
}

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", app: "mng-duck-hunt", port: PORT, activeUsername, connected: Boolean(connection) });
});

app.get("/api/avatar", async (req, res) => {
  const username = String(req.query.user || "").trim();
  const avatarUrl = trustedAvatarUrl(req.query.url);

  if (!avatarUrl) {
    res.set("Content-Type", "image/svg+xml");
    res.set("Cache-Control", "public, max-age=86400");
    return res.send(uretVarsayilanAvatarSvg(username));
  }

  const cleanUser = username.replace(/[^a-zA-Z0-9_.-]/g, "_").slice(0, 100);
  if (cleanUser) {
    try {
      const base = path.join(LAUNCHER_AVATAR_CACHE, `user_${cleanUser}`);
      const metadata = JSON.parse(fs.readFileSync(`${base}.json`, "utf8"));
      const buffer = fs.readFileSync(`${base}.bin`);
      if (buffer.length >= 2000) {
        res.set("Content-Type", metadata.contentType || "image/jpeg");
        res.set("Cache-Control", "public, max-age=900");
        return res.send(buffer);
      }
    } catch {}
  }

  const cacheKey = avatarUrl.href;
  const cached = avatarCache.get(cacheKey);
  if (cached) {
    res.set("Content-Type", cached.contentType);
    res.set("Cache-Control", "public, max-age=900");
    return res.send(cached.buffer);
  }

  try {
    const response = await fetch(avatarUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36",
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
        "Referer": "https://www.tiktok.com/"
      },
      signal: AbortSignal.timeout(6000)
    });
    const contentType = response.headers.get("content-type") || "";
    if (response.ok && contentType.startsWith("image/")) {
      const buffer = Buffer.from(await response.arrayBuffer());
      if (buffer.length && buffer.length <= 8 * 1024 * 1024) {
        avatarCache.set(cacheKey, { buffer, contentType });
        if (avatarCache.size > 400) avatarCache.delete(avatarCache.keys().next().value);
        res.set("Content-Type", contentType);
        res.set("Cache-Control", "public, max-age=900");
        return res.send(buffer);
      }
    }
  } catch {}

  res.set("Content-Type", "image/svg+xml");
  res.set("Cache-Control", "public, max-age=3600");
  res.send(uretVarsayilanAvatarSvg(username));
});

app.post("/api/disconnect", (_req, res) => {
  disconnect();
  res.json({ ok: true });
});

function imageUrlFrom(...candidates) {
  for (const item of candidates) {
    if (!item) continue;
    if (typeof item === "string" && item.trim()) return item.trim();
    if (Array.isArray(item?.urlList) && item.urlList[0]) return item.urlList[0];
    if (Array.isArray(item?.url_list) && item.url_list[0]) return item.url_list[0];
    if (Array.isArray(item?.urls) && item.urls[0]) return item.urls[0];
    if (typeof item?.url === "string" && item.url.trim()) return item.url.trim();
    if (typeof item?.uri === "string" && item.uri.trim()) return item.uri.trim();
  }
  return null;
}

function playerFrom(data) {
  const user = data.user || data.author || data.sender || data;
  const id = String(user.userId || user.user_id || user.id || user.secUid || user.uniqueId || "").trim();
  if (!id) return null;
  const nickname = String(user.nickname || user.uniqueId || user.unique_id || user.name || id).trim();
  const avatar = imageUrlFrom(user.avatarLarge, user.avatar_large, user.profilePictureUrl, user.profile_picture_url, user.avatarThumb, user.avatar_thumb, user.avatarMedium, user.avatar_medium, user.avatar);
  const avatarFallback = imageUrlFrom(user.avatarThumb, user.avatar_thumb, user.avatarMedium, user.avatar_medium, user.avatar);
  return { id, nickname, avatar, avatarFallback };
}

function giftFrom(data) {
  const extended = data.extendedGiftInfo || {};
  const detail = data.giftDetails || {};
  const gift = data.gift || {};
  const count = Math.max(1, Number(data.repeatCount || data.repeat_count || data.comboCount || data.combo_count || data.count || extended.count || 1) || 1);
  const coins = Math.max(1, Number(extended.diamondCount || extended.diamond_count || detail.diamondCount || detail.diamond_count || data.diamondCount || data.diamond_count || gift.diamond_count || 1) || 1);
  const giftId = extended.id || data.giftId || data.gift_id || detail.giftId || detail.gift_id || gift.id || null;
  const giftName = extended.name || extended.giftName || detail.name || detail.giftName || data.giftName || gift.name || "Hediye";
  const giftImage = imageUrlFrom(extended.image, extended.icon, detail.image, detail.icon, gift.image, gift.icon);

  let duckType = "normal";
  if (coins >= 100) {
    duckType = "boss";
  } else if (coins >= 10) {
    duckType = "golden";
  }

  return { giftId, giftName, coins, count, giftImage, duckType };
}

function broadcast(msg) {
  const payload = JSON.stringify(msg);
  for (const client of wss.clients) {
    if (client.readyState === 1) client.send(payload);
  }
}

function disconnect() {
  if (!connection) return;
  try { connection.disconnect(); } catch {}
  connection = null;
  activeUsername = "";
  broadcast({ type: "status", state: "idle", message: "TikTok bağlantısı kesildi." });
}

function connect(username) {
  const cleanUsername = String(username || "").replace(/^@/, "").trim();
  if (!cleanUsername) {
    broadcast({ type: "status", state: "error", message: "TikTok kullanıcı adı boş olamaz." });
    return;
  }

  disconnect();
  activeUsername = cleanUsername;
  broadcast({ type: "status", state: "connecting", message: `@${cleanUsername} yayınına bağlanılıyor...` });

  const opts = {};
  const key = eulerKey();
  if (key) opts.signApiKey = key;

  connection = new TikTokLiveConnection(cleanUsername, opts);
  const activeConnection = connection;

  connection.on("error", (error) => {
    if (connection !== activeConnection) return;
    broadcast({ type: "status", state: "error", message: error?.message || "TikTok bağlantı hatası." });
  });

  connection.connect()
    .then(() => {
      if (connection !== activeConnection) return;
      broadcast({ type: "status", state: "connected", username: cleanUsername, message: `@${cleanUsername} yayını bağlandı!` });
    })
    .catch((error) => {
      if (connection !== activeConnection) return;
      broadcast({ type: "status", state: "error", message: error?.message || "Yayın bulunamadı veya bağlantı kurulamadı." });
    });

  if (WebcastEvent.GIFT) {
    connection.on(WebcastEvent.GIFT, (data) => {
      const player = playerFrom(data);
      if (!player) return;
      const gift = giftFrom(data);
      widgetGiftPost({
        username: player.id,
        nickname: player.nickname,
        avatar: player.avatar,
        giftName: gift.giftName || "Hediye",
        giftImage: String(gift.giftImage || ""),
        coins: Number(gift.coins) || 0
      });
      broadcast({ type: "duck-event", event: "gift", player, ...gift });
    });
  }

  if (WebcastEvent.LIKE) {
    connection.on(WebcastEvent.LIKE, (data) => {
      const player = playerFrom(data);
      if (!player) return;
      const likeBatch = Math.max(1, Number(data.count ?? data.likeCount ?? 1) || 1);
      widgetLikePost({ username: player.id, nickname: player.nickname, avatar: player.avatar, likeCount: likeBatch });
      broadcast({ type: "duck-event", event: "like", player, count: likeBatch });
    });
  }

  if (WebcastEvent.FOLLOW) {
    connection.on(WebcastEvent.FOLLOW, (data) => {
      const player = playerFrom(data);
      if (player) broadcast({ type: "duck-event", event: "follow", player });
    });
  }

  if (WebcastEvent.CHAT) {
    connection.on(WebcastEvent.CHAT, (data) => {
      const player = playerFrom(data);
      if (player) {
        broadcast({
          type: "duck-event",
          event: "chat",
          player,
          comment: String(data.comment || "").slice(0, 80)
        });
      }
    });
  }

  if (WebcastEvent.MEMBER) {
    connection.on(WebcastEvent.MEMBER, (data) => {
      const player = playerFrom(data);
      if (player) {
        broadcast({
          type: "duck-event",
          event: "member",
          player
        });
      }
    });
  }

  connection.on(WebcastEvent.DISCONNECTED, () => {
    if (connection === activeConnection) {
      broadcast({ type: "status", state: "disconnected", message: "TikTok bağlantısı kesildi." });
    }
  });
}

let topVictims = [];
let topSurvivors = [];

wss.on("connection", (ws) => {
  ws.send(JSON.stringify({
    type: "status",
    state: connection ? "connected" : "idle",
    username: activeUsername,
    message: activeUsername ? `@${activeUsername} yayınına bağlı.` : "Yayıncı kullanıcı adını girin veya test modunda oynayın."
  }));

  ws.send(JSON.stringify({
    type: "leaderboard",
    victims: topVictims,
    survivors: topSurvivors
  }));

  ws.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    if (msg.type === "connect") {
      connect(msg.username);
    } else if (msg.type === "disconnect") {
      disconnect();
    } else if (msg.type === "test-gift") {
      const sampleNames = ["Ahmet_TR", "Selin_07", "Can_Gamer", "Ece_Yildiz", "Kral_Oyuncu", "Bahar_Can", "Emre_Pro", "Deniz_Mavi"];
      const randNick = sampleNames[Math.floor(Math.random() * sampleNames.length)];
      const samplePlayer = {
        id: (msg.nickname || randNick).toLowerCase(),
        nickname: msg.nickname || randNick,
        avatar: `/api/avatar?user=${encodeURIComponent(msg.nickname || randNick)}`
      };
      const coins = msg.coins || (msg.duckType === "boss" ? 199 : msg.duckType === "golden" ? 25 : 1);
      const giftName = msg.giftName || (msg.duckType === "boss" ? "Money Gun" : msg.duckType === "golden" ? "Donut" : "Gül");
      const duckType = msg.duckType || (coins >= 100 ? "boss" : coins >= 10 ? "golden" : "normal");

      broadcast({
        type: "duck-event",
        event: "gift",
        player: samplePlayer,
        giftName,
        coins,
        count: msg.count || 1,
        duckType
      });
    } else if (msg.type === "update-leaderboard") {
      if (Array.isArray(msg.victims)) topVictims = msg.victims.slice(0, 10);
      if (Array.isArray(msg.survivors)) topSurvivors = msg.survivors.slice(0, 10);
      if (Array.isArray(msg.entries)) topVictims = msg.entries.slice(0, 10);
      broadcast({ type: "leaderboard", victims: topVictims, survivors: topSurvivors, entries: topVictims });
    }
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`🦆 MNG Duck Hunt sunucusu http://localhost:${PORT} portunda çalışıyor.`);
});
