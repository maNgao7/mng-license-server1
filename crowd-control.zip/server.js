import express from "express";
import http from "http";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { WebSocketServer } from "ws";
import { TikTokLiveConnection, WebcastEvent } from "tiktok-live-connector";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT || 3020);

const app = express();
app.use(express.static(path.join(__dirname, "public")));
app.use("/catalog-assets", express.static(path.join(__dirname, "..", "tiktok-vs", "public", "assets"), { maxAge: "30d", immutable: true }));
const sharedBackgroundsPath = path.join(__dirname, "..", "tiktok-vs", "public", "assets", "backgrounds");
app.use("/shared-backgrounds", express.static(sharedBackgroundsPath));
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

const avatarCache = new Map();
const AVATAR_HOSTS = ["tiktokcdn.com", "byteimg.com", "ibytedtos.com", "tiktokv.com", "pravatar.cc", "unavatar.io"];
const GIFT_CATALOG_PATH = path.join(__dirname, "..", "tiktok-vs", ".gift-catalog.json");
const GORSEL_KUTUPHANE_PATH = path.join(__dirname, "..", "tiktok-vs", "public", "assets", "gift-images", "_kutuphane.json");
const LAUNCHER_AVATAR_CACHE = path.join(__dirname, "..", "tiktok-vs", ".avatar-cache");
let giftCatalog = [];
const gorselKutuphanesi = new Map();

const TURKISH_GIFT_ALIASES = {
  "gul": "Rose.png",
  "gül": "Rose.png",
  "rose": "Rose.png",
  "nazar": "Nazar.png",
  "nazar boncugu": "Nazar.png",
  "nazar boncuğu": "Nazar.png",
  "eye on the ball": "Eye_on_the_Ball.png",
  "donut": "Doughnut.png",
  "doughnut": "Doughnut.png",
  "sapka ve biyik": "Hat_and_Mustache.png",
  "şapka ve bıyık": "Hat_and_Mustache.png",
  "sapka biyik": "Hat_and_Mustache.png",
  "şapka bıyık": "Hat_and_Mustache.png",
  "hat and mustache": "Hat_and_Mustache.png",
  "parfum": "Perfume.png",
  "parfüm": "Perfume.png",
  "perfume": "Perfume.png",
  "cay": "Tea.png",
  "çay": "Tea.png",
  "tea": "Tea.png",
  "turk kahvesi": "Turkish_coffee.png",
  "türk kahvesi": "Turkish_coffee.png",
  "turkish coffee": "Turkish_coffee.png",
  "coffee": "Turkish_coffee.png",
  "kahve": "Turkish_coffee.png",
  "money gun": "Money_Gun.png",
  "para tabancasi": "Money_Gun.png",
  "para tabancası": "Money_Gun.png",
  "kalp": "Heart.png",
  "heart": "Heart.png",
  "aslan": "Lion.png",
  "lion": "Lion.png"
};

function normalizeGiftName(name) {
  return String(name || "")
    .trim()
    .toLowerCase()
    .replace(/\.\.\.$/, "")
    .replace(/\s+/g, " ")
    .trim();
}

try {
  if (fs.existsSync(GORSEL_KUTUPHANE_PATH)) {
    const list = JSON.parse(fs.readFileSync(GORSEL_KUTUPHANE_PATH, "utf8"));
    if (Array.isArray(list)) {
      list.forEach((entry) => {
        if (entry.name && entry.file) {
          gorselKutuphanesi.set(normalizeGiftName(entry.name), entry.file);
        }
      });
    }
  }
} catch (e) {
  console.warn("Görsel kütüphanesi okunamadı:", e);
}

function resolveAssetUrl(file) {
  if (!file) return null;
  const p1 = path.join(__dirname, "..", "tiktok-vs", "public", "assets", "gift-images", file);
  if (fs.existsSync(p1)) return `/catalog-assets/gift-images/${file}`;
  const p2 = path.join(__dirname, "..", "tiktok-vs", "public", "assets", "gift-catalog", file);
  if (fs.existsSync(p2)) return `/catalog-assets/gift-catalog/${file}`;
  return `/catalog-assets/gift-images/${file}`;
}

function findLocalGiftImage(name) {
  const norm = normalizeGiftName(name);
  if (!norm) return null;
  if (TURKISH_GIFT_ALIASES[norm]) {
    return resolveAssetUrl(TURKISH_GIFT_ALIASES[norm]);
  }
  const normSimple = norm.replace(/[^a-z0-9]/g, "");
  for (const [aliasKey, file] of Object.entries(TURKISH_GIFT_ALIASES)) {
    const aliasSimple = aliasKey.replace(/[^a-z0-9]/g, "");
    if (normSimple === aliasSimple || normSimple.includes(aliasSimple) || aliasSimple.includes(normSimple)) {
      return resolveAssetUrl(file);
    }
  }
  if (gorselKutuphanesi.has(norm)) {
    return resolveAssetUrl(gorselKutuphanesi.get(norm));
  }
  for (const [key, file] of gorselKutuphanesi.entries()) {
    if (norm.startsWith(key) || key.startsWith(norm)) {
      return resolveAssetUrl(file);
    }
  }
  return null;
}

try {
  const parsedCatalog = JSON.parse(fs.readFileSync(GIFT_CATALOG_PATH, "utf8"));
  giftCatalog = Array.isArray(parsedCatalog) ? parsedCatalog : [];
} catch {}

const FALLBACK_GIFT_ASSET = path.join(__dirname, "..", "tiktok-vs", "public", "assets", "gift-catalog", "balon-hediyesi.png");

app.get("/api/gifts", (_req, res) => {
  const query = String(_req.query.query || "").trim().toLowerCase();
  const requestedIds = new Set(
    String(_req.query.ids || "").split(",").map((id) => id.trim()).filter(Boolean)
  );
  const requestedLimit = Number(_req.query.limit);
  const limit = Math.max(24, Math.min(Number.isFinite(requestedLimit) ? requestedLimit : 80, 100));
  const results = [];
  const addedIds = new Set();
  const addedNames = new Set();

  const addGift = (gift) => {
    const id = String(gift.id || gift.name || "");
    if (!id || addedIds.has(id) || results.length >= limit) return;
    const name = String(gift.name || "Hediye");
    const normalizedName = normalizeGiftName(name);
    if (addedNames.has(normalizedName)) return;

    if (query) {
      const matchDirect = name.toLowerCase().includes(query) || id.toLowerCase().includes(query);
      let matchAlias = false;
      for (const [alias, file] of Object.entries(TURKISH_GIFT_ALIASES)) {
        if ((alias.includes(query) || query.includes(alias)) && (normalizedName.includes(alias) || file.toLowerCase().includes(query))) {
          matchAlias = true;
          break;
        }
      }
      if (!matchDirect && !matchAlias) return;
    }

    addedIds.add(id);
    addedNames.add(normalizedName);

    const localImg = findLocalGiftImage(name);
    const image = localImg
      || (gift.image && !String(gift.image).startsWith("http") ? `/catalog-assets/${String(gift.image).replace(/^assets\//, "")}` : null)
      || (gift.image ? `/api/gift-image?url=${encodeURIComponent(String(gift.image))}` : "/catalog-assets/gift-catalog/balon-hediyesi.png");

    results.push({ id, name, coins: Math.max(0, Number(gift.coins) || 0), image });
  };

  for (const gift of giftCatalog) {
    if (requestedIds.has(String(gift.id))) addGift(gift);
  }
  for (const gift of giftCatalog) {
    addGift(gift);
  }
  for (const [normName, file] of gorselKutuphanesi.entries()) {
    if (results.length >= limit) break;
    const cleanName = file.replace(/\.png$/i, "").replace(/_/g, " ");
    const id = "gift_" + normName.replace(/[^a-z0-9]/g, "_");
    addGift({ id, name: cleanName, coins: 10, image: `gift-images/${file}` });
  }

  res.json(results);
});

app.get("/api/backgrounds", (_req, res) => {
  try {
    const files = fs.readdirSync(sharedBackgroundsPath).filter((file) => /\.mp4$/i.test(file)).slice(0, 48);
    res.json(files.map((file) => {
      const baseName = file.replace(/\.mp4$/i, "");
      const thumbFile = path.join(sharedBackgroundsPath, "thumbs", `${baseName}.jpg`);
      const hasThumb = fs.existsSync(thumbFile);
      return {
        name: baseName,
        src: `/shared-backgrounds/${encodeURIComponent(file)}`,
        thumb: hasThumb ? `/shared-backgrounds/thumbs/${encodeURIComponent(baseName)}.jpg` : null
      };
    }));
  } catch { res.json([]); }
});

function trustedAvatarUrl(value) {
  try {
    const parsed = new URL(value);
    const trustedHost = AVATAR_HOSTS.some((host) => parsed.hostname === host || parsed.hostname.endsWith(`.${host}`));
    return parsed.protocol === "https:" && trustedHost ? parsed : null;
  } catch {
    return null;
  }
}

function uretVarsayilanAvatarSvg(isim) {
  const harf = (isim || "?").trim().charAt(0).toUpperCase() || "?";
  let hash = 0;
  for (let i = 0; i < (isim || "").length; i++) {
    hash = (hash << 5) - hash + (isim || "").charCodeAt(i);
    hash |= 0;
  }
  const renkler = ["#ef4444", "#f97316", "#f59e0b", "#10b981", "#06b6d4", "#3b82f6", "#8b5cf6", "#ec4899", "#ff4d6d"];
  const bg = renkler[Math.abs(hash) % renkler.length];
  return `<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128">
    <circle cx="64" cy="64" r="64" fill="${bg}"/>
    <text x="64" y="80" font-size="64" font-weight="900" font-family="system-ui, -apple-system, sans-serif" fill="#ffffff" text-anchor="middle" dominant-baseline="central">${harf}</text>
  </svg>`;
}

app.get("/api/avatar", async (req, res) => {
  const username = String(req.query.user || "").trim();
  const avatarUrl = trustedAvatarUrl(req.query.url);

  // 1. URL yoksa veya geçersizse direkt SVG dön
  if (!avatarUrl) {
    res.set("Content-Type", "image/svg+xml");
    res.set("Cache-Control", "public, max-age=86400");
    return res.send(uretVarsayilanAvatarSvg(username));
  }

  // 2. Launcher disk cache kontrolü
  const cleanUser = username.replace(/[^a-zA-Z0-9_.-]/g, "_").slice(0, 100);
  if (cleanUser) {
    try {
      const base = path.join(LAUNCHER_AVATAR_CACHE, `user_${cleanUser}`);
      const metadata = JSON.parse(fs.readFileSync(`${base}.json`, "utf8"));
      const buffer = fs.readFileSync(`${base}.bin`);
      if (buffer.length >= 2000) {
        res.set("Content-Type", metadata.contentType || "image/jpeg");
        res.set("Cache-Control", "public, max-age=900");
        return res.send(buffer);
      }
    } catch {}
  }

  // 3. Bellek cache
  const cacheKey = avatarUrl.href;
  const cached = avatarCache.get(cacheKey);
  if (cached) {
    res.set("Content-Type", cached.contentType);
    res.set("Cache-Control", "public, max-age=900");
    return res.send(cached.buffer);
  }

  // 4. Doğrudan fetch
  try {
    const response = await fetch(avatarUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36",
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
        "Referer": "https://www.tiktok.com/"
      },
      signal: AbortSignal.timeout(6000)
    });
    const contentType = response.headers.get("content-type") || "";
    if (response.ok && contentType.startsWith("image/")) {
      const buffer = Buffer.from(await response.arrayBuffer());
      if (buffer.length && buffer.length <= 8 * 1024 * 1024) {
        avatarCache.set(cacheKey, { buffer, contentType });
        if (avatarCache.size > 400) avatarCache.delete(avatarCache.keys().next().value);
        res.set("Content-Type", contentType);
        res.set("Cache-Control", "public, max-age=900");
        return res.send(buffer);
      }
    }
  } catch {}

  // Fallback: Renkli SVG avatar
  res.set("Content-Type", "image/svg+xml");
  res.set("Cache-Control", "public, max-age=3600");
  res.send(uretVarsayilanAvatarSvg(username));
});

function imageUrlFrom(...candidates) {
  for (const item of candidates) {
    if (!item) continue;
    if (typeof item === "string" && item.trim()) return item.trim();
    if (Array.isArray(item?.urlList) && item.urlList[0]) return item.urlList[0];
    if (Array.isArray(item?.url_list) && item.url_list[0]) return item.url_list[0];
    if (Array.isArray(item?.urls) && item.urls[0]) return item.urls[0];
    if (typeof item?.url === "string" && item.url.trim()) return item.url.trim();
    if (typeof item?.uri === "string" && item.uri.trim()) return item.uri.trim();
  }
  return null;
}

function playerFrom(data) {
  const user = data.user || data.author || data.sender || data;
  const id = String(user.userId || user.user_id || user.id || user.secUid || user.uniqueId || "").trim();
  if (!id) return null;
  const nickname = String(user.nickname || user.uniqueId || user.unique_id || user.name || id).trim();
  const avatar = imageUrlFrom(user.avatarLarge, user.avatar_large, user.profilePictureUrl, user.profile_picture_url, user.avatarThumb, user.avatar_thumb, user.avatarMedium, user.avatar_medium, user.avatar);
  const avatarFallback = imageUrlFrom(user.avatarThumb, user.avatar_thumb, user.avatarMedium, user.avatar_medium, user.avatar);
  return { id, nickname, avatar, avatarFallback };
}

function giftFrom(data) {
  const extended = data.extendedGiftInfo || {};
  const detail = data.giftDetails || {};
  const gift = data.gift || {};
  const count = Math.max(1, Number(data.repeatCount || data.repeat_count || data.comboCount || data.combo_count || data.count || extended.count || 1) || 1);
  const coin = Math.max(1, Number(extended.diamondCount || extended.diamond_count || detail.diamondCount || detail.diamond_count || data.diamondCount || data.diamond_count || gift.diamond_count || 1) || 1);
  const giftId = extended.id || data.giftId || data.gift_id || detail.giftId || detail.gift_id || gift.id || null;
  const giftName = extended.name || extended.giftName || detail.name || detail.giftName || data.giftName || gift.name || "Hediye";
  const catalogGift = giftCatalog.find((entry) =>
    String(entry.id) === String(giftId) || (entry.tiktokIds || []).some((id) => String(id) === String(giftId)) ||
    String(entry.name || "").toLowerCase() === String(giftName).toLowerCase()
  );
  const liveGiftImage = imageUrlFrom(extended.image, detail.image, data.image, gift.image, gift.icon);
  let catalogGiftImage = null;
  if (catalogGift?.image) {
    catalogGiftImage = String(catalogGift.image).startsWith("http")
      ? `/api/gift-image?url=${encodeURIComponent(String(catalogGift.image))}`
      : `/catalog-assets/${String(catalogGift.image).replace(/^assets\//, "")}`;
  }
  const localImage = findLocalGiftImage(giftName);
  let finalGiftImage = localImage || liveGiftImage || catalogGiftImage || "/catalog-assets/gift-catalog/balon-hediyesi.png";

  return {
    count,
    coins: count * coin,
    giftId: String(catalogGift?.id || giftId || giftName),
    catalogCoins: Number(catalogGift?.coins || coin) || 0,
    giftName,
    giftImage: finalGiftImage
  };
}

let connection = null;
let activeUsername = "";
let lastLeaderboard = [];
let allKillersMap = new Map();

function broadcast(payload) {
  const raw = JSON.stringify(payload);
  for (const client of wss.clients) {
    if (client.readyState === 1) client.send(raw);
  }
}

function eulerKey() {
  const candidates = [
    path.join(__dirname, "euler-api-key.txt"),
    path.join(__dirname, "..", "tiktok-vs", "euler-api-key.txt"),
    path.join(__dirname, "..", "mng-orbit", "euler-api-key.txt")
  ];
  for (const candidate of candidates) {
    try {
      const key = fs.readFileSync(candidate, "utf8").trim();
      if (key) return key;
    } catch {}
  }
  return undefined;
}

function disconnect() {
  if (!connection) return;
  try { connection.disconnect(); } catch {}
  connection = null;
}

function connect(username) {
  const cleanUsername = String(username || "").replace(/^@/, "").trim();
  if (!cleanUsername) {
    broadcast({ type: "status", state: "error", message: "TikTok kullanıcı adı gerekli." });
    return;
  }

  disconnect();
  activeUsername = cleanUsername;
  broadcast({ type: "status", state: "connecting", message: `@${cleanUsername} yayınına bağlanılıyor...` });

  connection = new TikTokLiveConnection(cleanUsername, { signApiKey: eulerKey() });
  const activeConnection = connection;

  connection.on("error", (error) => {
    if (connection !== activeConnection) return;
    broadcast({ type: "status", state: "error", message: error?.message || "TikTok bağlantısı kurulamadı." });
  });

  connection.connect()
    .then(() => {
      if (connection !== activeConnection) return;
      broadcast({ type: "status", state: "connected", message: `@${cleanUsername} yayınına bağlandı.` });
    })
    .catch((error) => {
      if (connection !== activeConnection) return;
      broadcast({ type: "status", state: "error", message: error?.message || "Yayın bulunamadı veya bağlantı kurulamadı." });
    });

  if (WebcastEvent.GIFT) connection.on(WebcastEvent.GIFT, (data) => {
    const player = playerFrom(data);
    if (!player) return;
    const gift = giftFrom(data);
    broadcast({ type: "crowd-event", event: "gift", player, ...gift });
  });

  if (WebcastEvent.LIKE) connection.on(WebcastEvent.LIKE, (data) => {
    const player = playerFrom(data);
    if (!player) return;
    const likeBatch = Math.max(1, Number(data.count ?? data.likeCount ?? 1) || 1);
    broadcast({ type: "crowd-event", event: "like", player, count: likeBatch });
  });

  if (WebcastEvent.FOLLOW) connection.on(WebcastEvent.FOLLOW, (data) => {
    const player = playerFrom(data);
    if (player) broadcast({ type: "crowd-event", event: "follow", player });
  });

  if (WebcastEvent.SOCIAL) connection.on(WebcastEvent.SOCIAL, (data) => {
    const action = String(data.displayType || data.action || data.label || "").toLowerCase();
    if (action.includes("follow")) {
      const player = playerFrom(data);
      if (player) broadcast({ type: "crowd-event", event: "follow", player });
    }
  });

  connection.on(WebcastEvent.DISCONNECTED, () => {
    if (connection === activeConnection) {
      broadcast({ type: "status", state: "disconnected", message: "TikTok bağlantısı kesildi." });
    }
  });
}

wss.on("connection", (ws) => {
  ws.send(JSON.stringify({
    type: "status",
    state: connection ? "connected" : "idle",
    message: activeUsername ? `@${activeUsername} yayını izleniyor.` : "Yayın kullanıcı adını girin."
  }));

  if (lastLeaderboard.length) {
    ws.send(JSON.stringify({ type: "leaderboard", entries: lastLeaderboard }));
  }

  const sortedKillers = [...allKillersMap.values()].sort((a, b) => b.kills - a.kills);
  if (sortedKillers.length) {
    ws.send(JSON.stringify({ type: "killers", entries: sortedKillers }));
  }

  ws.on("message", (raw) => {
    let message;
    try { message = JSON.parse(raw.toString()); } catch { return; }
    if (message.type === "connect") connect(message.username);
    if (message.type === "disconnect") {
      disconnect();
      activeUsername = "";
      broadcast({ type: "status", state: "idle", message: "Bağlantı kapatıldı." });
    }
    if (message.type === "leaderboard" && Array.isArray(message.entries)) {
      lastLeaderboard = message.entries;
      broadcast({ type: "leaderboard", entries: lastLeaderboard });
    }
    if (message.type === "killer" && message.killer) {
      const k = message.killer;
      const kId = String(k.id || k.nickname || "Katil");
      const existing = allKillersMap.get(kId) || {
        id: kId,
        nickname: String(k.nickname || "İzleyici"),
        avatar: k.avatar || null,
        kills: 0
      };
      existing.kills += (Number(k.kills) || 1);
      if (k.nickname) existing.nickname = k.nickname;
      if (k.avatar) existing.avatar = k.avatar;
      allKillersMap.set(kId, existing);

      const sortedKillers = [...allKillersMap.values()].sort((a, b) => b.kills - a.kills);
      broadcast({ type: "killers", entries: sortedKillers });
    }
  });
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, app: "mng-crowd-control", connected: !!connection, activeUsername });
});

app.post("/api/disconnect", (_req, res) => {
  disconnect();
  res.json({ ok: true, message: "Bağlantı kesildi" });
});

app.post("/api/shutdown", (_req, res) => {
  res.json({ ok: true });
  setTimeout(() => {
    guvenliKapat();
    process.exit(0);
  }, 100);
});

function guvenliKapat() {
  disconnect();
  try { server.close(); } catch {}
}
process.on("SIGINT", () => { guvenliKapat(); process.exit(0); });
process.on("SIGTERM", () => { guvenliKapat(); process.exit(0); });

server.listen(PORT, "127.0.0.1", () => {
  console.log(`MNG Crowd Control: http://127.0.0.1:${PORT}`);
});
